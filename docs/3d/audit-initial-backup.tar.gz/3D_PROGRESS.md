# Refonte 3D — progression et reprise

Mise à jour : 2026-11-17. Branche active : `feat/3d-pro`.
HEAD : `940e53715950c2ed53434b9c032d88e9d3bfc665` (aucun nouveau commit).
Étape active : 1, audit statique réalisé ; validation exécutable de V2 en attente de correction de base.
Étapes 2 à 6 : non commencées. Aucune fonctionnalité produit nouvelle n'est revendiquée.

## Première action à la reprise

1. Lire ce fichier, `3D_PLAN.md`, `docs/3d/AUDIT.md`, puis vérifier `git branch --show-current` et
   `git status --short`. Rester exclusivement sur `feat/3d-pro`.
2. Vérifier la réponse humaine sur le fast-forward vers `origin/v2/implementation`. Sans réponse
   explicite, ne pas fusionner. La branche distante a été confirmée au commit
   `010d4d9e54d0990cbfe0f1368341ae386034107d`. `v2` n'existe pas sous ce nom exact.
3. Si autorisé, sauvegarder les fichiers d'audit et vérifier leur absence dans la cible, puis
   `git merge --ff-only origin/v2/implementation`. Si le fast-forward échoue, réexaminer sans reset,
   rebase, cherry-pick ou fusion alternative automatique. Ne pas modifier `main` ni la branche V2.
4. Relire les `AGENTS.md` de la nouvelle base et son harnais ; préparer ensuite l'ADR de liaison
   explicite des occurrences, en distinguant le choix d'identité de la simple mise au point du rendu.
5. Disposer de Go compatible avec `go.mod` (`go 1.27.4`) et de Node compatible avec Vite
   (`^20.19.0 || >=22.12.0`), installer avec `npm ci`, lancer les checks de base.
6. Reprendre l'étape 2 par les tests de non-régression et les changements locaux au viewer ; ne pas
   attendre des assets fiables pour améliorer les états d'absence, la caméra ou les transitions.

## Travail réalisé et preuves

| Travail | Fichiers / sources | Vérification | Statut |
|---|---|---|---|
| Intégrité et base Git | HEAD, branches, merge-base, ls-remote | Branche propre initialement ; HEAD identique à main ; 101 commits V2 absents | Écart identifié, correction en attente d'accord |
| Analyse intégrale des deux ZIP | Extraction `/tmp/stp-3d-audit/` ; SHA dans l'audit/manifeste | 9 + 436 entrées, pas d'assets automobiles binaires | Réalisé |
| Alignement des inventaires | CSV des ZIP, `internal/sampledata/{multipla,valhalla,common}.go` des deux bases | 220 + 153 + 45 = 418 clés, aucune différence | Réalisé |
| Analyse moteur V2 | `git show origin/v2/implementation:...` | Défauts occurrence, clé de scène, quantité, géométrie et éclaté consignés dans AUDIT | Réalisé par lecture statique |
| Inspection visuelle historique | 3 captures `docs/v2/captures/lot-d` de V2 | Images extraites et vues ; pas des captures nouvelles | Réalisé, limite explicitée |
| Recherche supplémentaire | Sources Aston Martin, Khronos, Commons, sites de modèles | Architecture hybride confirmée ; piste CC Attribution non téléchargée | Partiel : assets exacts manquants |
| Récupération des 12 photos | Script fourni, inspecté puis exécuté | 0/12 ; DNS dans sandbox, métadonnées numériques puis HTTP 429 hors sandbox | Échec documenté |
| Manifeste des 418 types | `docs/3d/assets-manifest.json` | Aucun ID runtime inventé, aucune géométrie déclarée fiable | Créé |
| Contrôle reproductible | `scripts/audit_3d_assets.py`, `scripts/test_audit_3d_assets.py` | Intégrité du seed et refus des fausses déclarations | Résultats ci-dessous |
| Plan et points de reprise | `3D_PLAN.md`, ce fichier, `docs/3d/AUDIT.md` | Étapes, dépendances, preuves et première action précisées | Créés |

## Fichiers de cette unité

- `3D_PLAN.md` : séquence de livraison et critères, proposition de correction de base.
- `3D_PROGRESS.md` : état, preuves, commandes et prochaine action.
- `docs/3d/AUDIT.md` : diagnostic du code, archives, ressources, approbations et limites.
- `docs/3d/assets-manifest.json` : inventaire de recherche ; 418 géométries `unavailable`, licence,
  provenance, preuve et placement non résolus ; deux représentations historiques séparées.
- `scripts/audit_3d_assets.py` : contrôle sans DB de l'alignement des clés et des affirmations de couverture.
- `scripts/test_audit_3d_assets.py` : cas valides et cas d'identité/couverture incorrectes.

Aucun fichier produit, dépendance, API, migration, ADR acceptée ou snapshot n'a été modifié.
Les fichiers sont sauvegardés dans le dépôt mais pas encore committés : garder le fast-forward possible
avant le premier commit d'audit. Aucun push, aucune PR, aucune fusion effectués.

## Commandes et résultats

- `git ls-remote --heads origin 'v2*' 'feat/3d-pro'` : réussi avec accès réseau hors sandbox ;
  confirme les commits consignés plus haut. Essai sandbox : résolution DNS impossible.
- `python3 scripts/audit_3d_assets.py` : réussi, 418 clés alignées avec le seed ; groupes
  `commun: 45, multipla: 220, valhalla: 153`, géométries `unavailable: 418`.
- `python3 -m unittest discover -s scripts -p 'test_audit_3d_assets.py' -v` : réussi,
  2 tests, dont une table de 11 cas incorrects (doublon, clé absente/inconnue, mauvais véhicule,
  statut inventé, asset incohérent/absent/sans licence, exactitude ou placement sans preuve).
- `git diff --check` : réussi ; les nouveaux fichiers sont encore non suivis, donc ce contrôle Git
  seul ne constitue pas une revue de leur contenu.
- `make test` : échec immédiat, sortie exacte :

  ```text
  go test ./...
  make: go: No such file or directory
  make: *** [Makefile:27: test] Error 127
  ```

- `make lint` : essaie d'abord `npm ci` (node_modules absent), puis échoue avant Go/front lint :

  ```text
  npm ERR! code EAI_AGAIN
  npm ERR! syscall getaddrinfo
  npm ERR! request to https://registry.npmjs.org/vite/-/vite-8.3.8.tgz failed, reason: getaddrinfo EAI_AGAIN registry.npmjs.org
  make: *** [Makefile:65: web/node_modules] Error 1
  ```

  Node présent : `v18.19.1`, npm `9.2.0`. Avertissements `EBADENGINE` sur Vite, plugin React,
  Playwright et oxlint. Ne pas contourner les exigences en changeant les versions verrouillées.
- Photos : script original exécuté, puis correctif temporaire
  `html.unescape(v.get('value',''))` → `html.unescape(str(v.get('value','')))`.
  Le dernier essai (`/tmp/stp-3d-audit/photos-download-fixed.log`) finit par
  `0/12 images téléchargées et revérifiées`, exit 2, HTTP 429 sur les 12 fichiers.
  Aucun fichier image ni crédit de téléchargement réussi à importer. Ne pas répéter les appels
  immédiatement ; conserver les contrôles de licence et traiter les métadonnées non textuelles.
- Build, tests unitaires V2, Playwright, CI, mesures GPU/FPS : non exécutés ; base produit et outils
  non prêts. Chrome système et un cache Playwright existent ; aucune validation WebGL actuelle.

## Couverture et limites

418 types de catalogue inventoriés ; 0 géométrie de pièce fiable acquise ; 0 placement constructeur
validé. Aucun nombre d'occurrences réellement représentées mesuré sur une BOM complète en exécution.
Les 56/52 objets des fixtures démo V2 sont des sous-ensembles, pas une preuve de couverture complète.
Les 13 éléments non géométriques du CSV restent classés tels quels, sans inventer de mesh.

Risques encore ouverts : licence et découpage des modèles candidats, architecture d'identité stable,
ancien mesh après remplacement, occurrence confondue avec son sous-ensemble, emplacements de quantités
supplémentaires inconnus, recherche masquant une sélection, focus ne rouvrant pas l'onglet Détail.
Rien de cela n'est annoncé comme corrigé. La définition de terminé du projet n'est pas atteinte.
